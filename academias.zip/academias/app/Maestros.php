<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Maestros extends Model
{
    //
}
