<?php $__env->startSection('content'); ?>
<div class="login-box bg-info"> 
  <div class="login-logo">
    <a href="../../index2.html"><b>ACADEMIAS</b></a>
  </div>
  <!-- /.login-logo -->
  <div class="login-box-body">
    <strong><h4><p class="login-box-msg">Iniciar sesión</p></h4></strong>

    <form action="<?php echo e(route('login')); ?>" method="post">
      <?php echo csrf_field(); ?>

      <div class="form-group has-feedback">
        <input type="email" name="email" id="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" placeholder="Email" value="<?php echo e(old('email')); ?>" required>
        <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
         <?php if($errors->has('email')): ?>
          <span class="invalid-feedback" role="alert">
              <strong><?php echo e($errors->first('email')); ?></strong>
          </span>
          <?php endif; ?>
      </div>
      <div class="form-group has-feedback">
        <input type="password" name="password" id="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" placeholder="Password">
        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
          <?php if($errors->has('password')): ?>
          <span class="invalid-feedback" role="alert">
              <strong><?php echo e($errors->first('password')); ?></strong>
          </span>
          <?php endif; ?>
      </div>
      <div class="row">
        <div class="col-xs-8">
         
        </div>
        <!-- /.col -->
        <div class="col-xs-4">
          <button type="submit" class="btn btn-success btn-block btn-flat">Acceder</button>
        </div>
        <!-- /.col -->
      </div>
    </form>

  </div>
  <!-- /.login-box-body -->
</div>
<!-- /.login-box -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/david/Escritorio/laravel/academias/resources/views/auth/login.blade.php ENDPATH**/ ?>